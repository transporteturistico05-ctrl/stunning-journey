/**
 * MyWeakSet — implementación fiel al spec ECMA-262 del constructor WeakSet.
 *
 * Referencia: ECMAScript® 2025+ Language Specification
 *   23.4.1.1 WeakSet ( [ iterable ] )
 *   23.4.3.1 WeakSet.prototype.add ( value )
 *   9.13 CanBeHeldWeakly ( arg )
 *
 * A diferencia de Map/WeakMap, WeakSet NO usa AddEntriesFromIterable:
 * itera el argumento directamente y llama a adder(value) con un solo
 * argumento, ya que cada entrada es un valor único, no un par [key, value].
 */

/**
 * CanBeHeldWeakly ( arg )
 * Determina si un valor puede usarse como referencia "débil":
 * cualquier objeto, o un symbol NO registrado (creado con Symbol(),
 * no con Symbol.for()).
 */
function CanBeHeldWeakly(value) {
  if (Object(value) === value) return true;
  if (typeof value === 'symbol' && Symbol.keyFor(value) === undefined) return true;
  return false;
}

class MyWeakSet {
  #data = new WeakMap();
  #symbolData = new Set();

  constructor(iterable) {
    // Paso 4: si no hay iterable, no hay nada más que hacer
    if (iterable === undefined || iterable === null) return;

    // Pasos 5-6: capturar `add` como propiedad y validar que sea invocable
    const adder = this.add;
    if (typeof adder !== 'function') {
      throw new TypeError('adder debe ser una función');
    }

    // Pasos 7-8: iterar y agregar cada valor, cerrando el iterador
    // correctamente si algo falla (mismo patrón que IfAbruptCloseIterator)
    const iterator = iterable[Symbol.iterator]();
    while (true) {
      const { value: next, done } = iterator.next();
      if (done) return this;

      try {
        adder.call(this, next);
      } catch (err) {
        if (typeof iterator.return === 'function') iterator.return();
        throw err;
      }
    }
  }

  add(value) {
    if (!CanBeHeldWeakly(value)) {
      throw new TypeError('El valor debe ser un objeto o un symbol no registrado');
    }
    if (typeof value === 'symbol') {
      this.#symbolData.add(value);
    } else {
      this.#data.set(value, true);
    }
    return this;
  }

  delete(value) {
    if (!CanBeHeldWeakly(value)) return false;
    return typeof value === 'symbol'
      ? this.#symbolData.delete(value)
      : this.#data.delete(value);
  }

  has(value) {
    if (!CanBeHeldWeakly(value)) return false;
    return typeof value === 'symbol'
      ? this.#symbolData.has(value)
      : this.#data.has(value);
  }

  get [Symbol.toStringTag]() {
    return 'WeakSet';
  }
}

module.exports = MyWeakSet;
module.exports.CanBeHeldWeakly = CanBeHeldWeakly;
