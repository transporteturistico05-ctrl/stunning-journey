/**
 * MyWeakSet — implementación fiel al spec ECMA-262 del constructor WeakSet.
 * Versión ES Modules (import/export).
 *
 * Referencia: ECMAScript® 2025+ Language Specification
 *   23.4.1.1 WeakSet ( [ iterable ] )
 *   23.4.3.1 WeakSet.prototype.add ( value )
 *   9.13 CanBeHeldWeakly ( arg )
 */

export function CanBeHeldWeakly(value) {
  if (Object(value) === value) return true;
  if (typeof value === 'symbol' && Symbol.keyFor(value) === undefined) return true;
  return false;
}

export class MyWeakSet {
  #data = new WeakMap();
  #symbolData = new Set();

  constructor(iterable) {
    if (iterable === undefined || iterable === null) return;

    const adder = this.add;
    if (typeof adder !== 'function') {
      throw new TypeError('adder debe ser una función');
    }

    const iterator = iterable[Symbol.iterator]();
    while (true) {
      const { value: next, done } = iterator.next();
      if (done) return this;

      try {
        adder.call(this, next);
      } catch (err) {
        if (typeof iterator.return === 'function') iterator.return();
        throw err;
      }
    }
  }

  add(value) {
    if (!CanBeHeldWeakly(value)) {
      throw new TypeError('El valor debe ser un objeto o un symbol no registrado');
    }
    if (typeof value === 'symbol') {
      this.#symbolData.add(value);
    } else {
      this.#data.set(value, true);
    }
    return this;
  }

  delete(value) {
    if (!CanBeHeldWeakly(value)) return false;
    return typeof value === 'symbol'
      ? this.#symbolData.delete(value)
      : this.#data.delete(value);
  }

  has(value) {
    if (!CanBeHeldWeakly(value)) return false;
    return typeof value === 'symbol'
      ? this.#symbolData.has(value)
      : this.#data.has(value);
  }

  get [Symbol.toStringTag]() {
    return 'WeakSet';
  }
}

export default MyWeakSet;
