const MyWeakSet = require('../src/weakset');

let passed = 0;
let failed = 0;

function assert(cond, msg) {
  if (cond) {
    passed++;
    console.log('PASS - ' + msg);
  } else {
    failed++;
    console.log('FAIL - ' + msg);
  }
}

// 1. Constructor vacío
const ws1 = new MyWeakSet();
assert(ws1 instanceof MyWeakSet, 'constructor vacío crea instancia');

// 2. add / has / delete básicos
const obj = {};
ws1.add(obj);
assert(ws1.has(obj) === true, 'has() detecta objeto agregado');
assert(ws1.has({}) === false, 'has() no detecta objeto distinto con misma forma');
ws1.delete(obj);
assert(ws1.has(obj) === false, 'delete() elimina correctamente');

// 3. Constructor con iterable
const a = {}, b = {}, c = {};
const ws2 = new MyWeakSet([a, b, c]);
assert(ws2.has(a) && ws2.has(b) && ws2.has(c), 'constructor con iterable agrega todo');

// 4. add() retorna this (chainable)
const ws3 = new MyWeakSet();
const result = ws3.add({});
assert(result === ws3, 'add() retorna this');

// 5. Rechaza primitivos
let threw = false;
try { ws3.add(5); } catch (e) { threw = e instanceof TypeError; }
assert(threw, 'add(5) lanza TypeError');

threw = false;
try { ws3.add('texto'); } catch (e) { threw = e instanceof TypeError; }
assert(threw, "add('texto') lanza TypeError");

threw = false;
try { new MyWeakSet([1, 2, 3]); } catch (e) { threw = e instanceof TypeError; }
assert(threw, 'constructor con iterable de primitivos lanza TypeError');

// 6. Symbols no registrados: válidos
const symNoReg = Symbol('privado');
const ws4 = new MyWeakSet();
ws4.add(symNoReg);
assert(ws4.has(symNoReg) === true, 'symbol no registrado es válido');

// 7. Symbols registrados (Symbol.for): inválidos
threw = false;
try { ws4.add(Symbol.for('compartido')); } catch (e) { threw = e instanceof TypeError; }
assert(threw, 'symbol registrado (Symbol.for) lanza TypeError');

// 8. Symbol.toStringTag
assert(Object.prototype.toString.call(ws1) === '[object WeakSet]', 'toStringTag correcto');

// 9. Comparación de comportamiento con WeakSet nativo
const native = new WeakSet();
const mine = new MyWeakSet();
const testObj = {};
native.add(testObj);
mine.add(testObj);
assert(native.has(testObj) === mine.has(testObj), 'comportamiento coincide con WeakSet nativo (has)');

let nativeThrew = false, mineThrew = false;
try { native.add(1); } catch (e) { nativeThrew = true; }
try { mine.add(1); } catch (e) { mineThrew = true; }
assert(nativeThrew === mineThrew, 'comportamiento coincide con WeakSet nativo (rechazo de primitivos)');

console.log(`\n${passed} pruebas OK, ${failed} fallidas.`);
process.exit(failed > 0 ? 1 : 0);
