# my-weakset

Implementación de `WeakSet` en JavaScript puro, fiel al algoritmo real de
ECMA-262 (23.4 WeakSet Objects), incluyendo soporte de **symbols no
registrados** como valores válidos (`CanBeHeldWeakly`).

## Instalación

No requiere dependencias. Copia `src/weakset.js` (CommonJS) o
`src/weakset.mjs` (ES Modules) a tu proyecto.

## Uso — CommonJS

```js
const MyWeakSet = require('./src/weakset');

const ws = new MyWeakSet();
const usuario = { nombre: 'Ana' };

ws.add(usuario);
console.log(ws.has(usuario)); // true
ws.delete(usuario);
console.log(ws.has(usuario)); // false
```

## Uso — ES Modules

```js
import MyWeakSet from './src/weakset.mjs';

const ws = new MyWeakSet([{}, {}, Symbol('privado')]);
```

## API

Igual que el `WeakSet` nativo:

- `new MyWeakSet([iterable])`
- `.add(value)` → retorna `this` (encadenable)
- `.delete(value)` → `boolean`
- `.has(value)` → `boolean`

Solo acepta **objetos** o **symbols no registrados** (`Symbol('desc')`,
no `Symbol.for('desc')`) como valores — igual que el `WeakSet` nativo.

## Correr las pruebas

```bash
npm test
```

Las pruebas comparan directamente el comportamiento contra el `WeakSet`
nativo de Node para confirmar equivalencia.

## Por qué no usa `AddEntriesFromIterable`

A diferencia de `Map`/`WeakMap`, `WeakSet` no reutiliza la operación
`AddEntriesFromIterable` del spec — itera el argumento directamente y
llama a `add(value)` con un solo argumento, porque cada entrada es un
valor individual, no un par `[key, value]`. Ver los comentarios en
`src/weakset.js` para el detalle paso a paso del algoritmo.
